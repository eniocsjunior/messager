levels = {
    0: 'debug',
    1: 'success',
    2: 'info',
    3: 'warning',
    4: 'error',
    5: 'critical'
}
