# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['messager', 'messager.interfaces']

package_data = \
{'': ['*']}

install_requires = \
['peewee[sql]>=3.17.8,<4.0.0']

setup_kwargs = {
    'name': 'messager',
    'version': '0.1.0',
    'description': 'Package to create log messages.',
    'long_description': "# Messager\nPackage to create log messages.\n\n## How to use\nInitially, we must configure the messaging server with the interfaces we want to use:\n```python\n\n>>> from messager import Message, File, SQL\n>>> file = File()\n>>> message = Message(app='my_app', interfaces=[file])\n```\nYou can also add interfaces after instantiating the Message class:\n```python\n>>> message.interfaces\n[<messager.interfaces.files.File object at 0xffffba9d1fd0>]\n>>> postgres = SQL(uri='postgres://user:password@localhost:5432/database')\n>>> sqlite = SQL(uri='sqlite:///mylogfile.db')\n>>> message.add_interface(postgres)\n>>> message.add_interface(sqlite)\n>>> message.interfaces\n[<messager.interfaces.files.File object at 0xffffba9d1fd0>, <messager.interfaces.sql.SQL object at 0xffffbad7a7d0>, <messager.interfaces.sql.SQL object at 0xffffbad78ac9>]\n```\nAfter instantiating the Message class, you can call the instance again in another part of the code:\n```python\n>>> message(module='my_module')\n```\nNow just create your messages:\n```python\n>>> message.debug('A debug message')\n>>> message.success('A success message')\n>>> message.info('A info message')\n>>> message.warning('A warning message')\n>>> message.error('A error message')\n>>> message.critical('A critical message')\n```\n",
    'author': 'eniocsjunior',
    'author_email': 'eniocsjunior@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
