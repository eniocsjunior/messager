# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['messager', 'messager.interfaces']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'messager',
    'version': '0.1.0',
    'description': 'Package to create log messages.',
    'long_description': "# Messager\nPackage to create log messages.\n\n## How to use\nInitially we must instantiate the interfaces we want to use:\n```python\nfrom messager import Terminal\nterminal = Terminal()\n```\nThe interfaces have 2 optional parameters:\n* min: Minimum level to run the interface.\n* max: Maximum level to run the interface.\n\nThe levels are:\n* 0: Debug\n* 1: Info\n* 2: Warning\n* 3: Error\n* 4: Critical\n\nAfter configuring the interfaces, it is necessary to add the interfaces to a Messages instance:\n```python\nfrom messager import Message\nmessage = Message(\n    app='Test',\n    interfaces=[terminal]\n)\n```\n\nIt is recommended but not mandatory to call the Message class in each module of your code:\n```python\nmessage(module='my_module')\n```\n\nThen, just call the appropriate method for your message:\n```python\nmessage.debug('My debug message')\nmessage.info('My info message')\nmessage.warning('My warning message')\nmessage.error('My error message')\nmessage.critical('My critical message')\n```\n",
    'author': 'eniocsjunior',
    'author_email': 'eniocsjunior@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
